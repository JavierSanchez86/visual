﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Security.Cryptography;
using System.Xml.Schema;
using System.Xml.XPath;
using System.IO.Compression;






namespace WsSunat
{
    public partial class Form1 : Form
    {
        string filename,ruta,ticket;
        string[] separados;
        byte[] ContentFile;
        

        public void GeneraFirma(string pFileXML, string pFilePFX, string pClavePFX)
        {
            try
            {
                XmlDocument oDocumento = new XmlDocument();
                oDocumento.PreserveWhitespace = true;

                using (StreamReader reader= new StreamReader(File.Open(pFileXML, FileMode.Open), Encoding.GetEncoding("ISO-8859-1")))
                        oDocumento.Load(reader);

                var YOO = oDocumento.GetElementsByTagName("ExtensionContent", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2").Item(0);//0 para resumen
                YOO.RemoveAll();

                X509Certificate2 oCertificado = new X509Certificate2(pFilePFX, pClavePFX, X509KeyStorageFlags.MachineKeySet);

                SignedXml signedXml = new SignedXml(oDocumento);
                signedXml.SigningKey = oCertificado.PrivateKey;
                Signature XMLSignature = signedXml.Signature;

                XmlDsigEnvelopedSignatureTransform env = new XmlDsigEnvelopedSignatureTransform();

                Reference reference = new Reference("");
                reference.AddTransform(env);
                XMLSignature.SignedInfo.AddReference(reference);

                KeyInfo keyinfo = new KeyInfo();
                KeyInfoX509Data x509Data = new KeyInfoX509Data(oCertificado);

                x509Data.AddSubjectName(oCertificado.Subject);

                keyinfo.AddClause(x509Data);
                XMLSignature.KeyInfo = keyinfo;
                XMLSignature.Id = "#SRC-20180504-1"; //Esto tu puedes ponerlo lo que desees
                signedXml.ComputeSignature();

                YOO.AppendChild(signedXml.GetXml());

                XmlWriterSettings settings = new XmlWriterSettings() { Encoding = Encoding.GetEncoding("ISO-8859-1") };

                using (XmlWriter writer = XmlWriter.Create(pFileXML, settings))
                    oDocumento.WriteTo(writer);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void button1_Click(object sender, EventArgs e)//firmar
        {
            GeneraFirma("E:\\cert\\20440120491-RC-20180428-1.xml", "E:\\cert\\CertificadoPFX.pfx", "bQfvKb7aNjTAdrqA");
           /* try
            {   
                XmlDocument xmlDoc = new XmlDocument();//creamos un documento XML
                X509Certificate2 uidCert = new X509Certificate2("E:\\cert\\LLAMA-PE-CERTIFICADO-DEMO-20396393868.pfx", "123456789", X509KeyStorageFlags.DefaultKeySet);//cargamos el certificado
                xmlDoc.Load("E:\\cert\\20396393868-RC-20180102-1.txt");//cargamos el archivo a firmar
                xmlDoc.PreserveWhitespace = true;//para que respete el formato con espacios

                SignXmlFile(xmlDoc, uidCert);//firmamos el documento XML
                
                
                 // Create an XML declaration. 
                XmlDeclaration xmldecl;
                xmldecl = xmlDoc.CreateXmlDeclaration("1.0", null, null);
                xmldecl.Encoding = "UTF-8";//"iso-8859-1";
                xmldecl.Standalone = "no";

                // Add the new node to the document.
                XmlElement root = xmlDoc.DocumentElement;
                xmlDoc.InsertBefore(xmldecl, root);

                
                xmlDoc.Save("E:\\20396393868-RC-20180102-1.xml");//guardamos el documento 
                //ZipFile.CreateFromDirectory("E:\\out", "E:\\20396393868-RC-20180102-00001.zip");//comprimir
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);
            }  */          
        }

        public static void SignXmlFile(XmlDocument xmlDoc, X509Certificate2 uidCert)
        {
           
            RSACryptoServiceProvider rsaKey = (RSACryptoServiceProvider)uidCert.PrivateKey;
            
            if (xmlDoc == null)//verificamos los argumentos
                throw new ArgumentException("xmlDoc");
            if (rsaKey == null)
                throw new ArgumentException("Key");

            SignedXml signedXml = new SignedXml(xmlDoc) /*{ SigningKey = certificate.PrivateKey }*/;//creamos un objeto SignedXml
            signedXml.SigningKey = rsaKey;//agregamos la clave al documentoSigned
            Reference reference = new Reference();//creamos una referencia a ser firmada
            reference.Uri = "";

            XmlDsigEnvelopedSignatureTransform env = new XmlDsigEnvelopedSignatureTransform();//añadimos un cubierta para transformar la referanci
            reference.AddTransform(env);

            signedXml.AddReference(reference);//añadimos la referencia al objeto SignedXml

            KeyInfo keyinfo = new KeyInfo();//añadimos un RSAKeyValue de la keyinfo(opcional, si se busca la clave para validar)

            KeyInfoX509Data clause = new KeyInfoX509Data();
            clause.AddSubjectName(uidCert.Subject);
            clause.AddCertificate(uidCert);
            keyinfo.AddClause(clause);
             //--
            signedXml.KeyInfo = keyinfo;
            
            signedXml.ComputeSignature();//obtenemos la firma
            

            XmlElement xmlDigitalSignature = signedXml.GetXml();//obtenemos la representacion de la firma y guardamos en el objeto XmlElement
            xmlDigitalSignature.Prefix = "ds";//--
            xmlDigitalSignature.SetAttribute("ID", "#SRC-20180102-1");//se establece el id de la etiqueta Signature
            AgregaPrefijo(xmlDigitalSignature);
            

            //xmlDoc.DocumentElement.AppendChild(xmlDoc.ImportNode(xmlDigitalSignature, true));//agregamos el elemento al documento xml----
            XmlNamespaceManager xmlmanager = new XmlNamespaceManager(xmlDoc.NameTable);
            xmlmanager.AddNamespace("ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2");
            
            XmlNode node = xmlDoc.SelectSingleNode("/SummaryDocuments/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent",xmlmanager);
            node.AppendChild(xmlDoc.ImportNode(xmlDigitalSignature, true));           
            
        }


        public Form1()
        {
            InitializeComponent();
        }

       
        private void txtExaminar_Click(object sender, EventArgs e)
        {
            OpenFileDialog archivoExaminar = new OpenFileDialog();
            archivoExaminar.Filter = "Archivos Zip (*.zip)|*.zip";//filtrar que archivos se podra cargar
            archivoExaminar.Title = "Archivos Zip";
            if (archivoExaminar.ShowDialog() == DialogResult.OK)//cuando se selecciona el archivo
            {
                txtRuta.Text = archivoExaminar.FileName;//se obtine la ruta del archivo
            }
            ruta  = txtRuta.Text;            
            separados = ruta.Split('\\');//separamos la ruta mediante '\'
            //txtFilename.Text =  separados[separados.Length-1];
            filename = separados[separados.Length - 1];
            ContentFile = File.ReadAllBytes(ruta);
            archivoExaminar.Dispose();
            
        }
        
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            Sunat.billServiceClient cliente = new Sunat.billServiceClient("BillServicePort");
            ticket = cliente.sendSummary(filename, ContentFile,"RC");//resumen
            //ticket = cliente.sendBill(filename, ContentFile,"FA");
            txtFilename.Text = ticket;
            cliente.getStatus(ticket);
            MessageBox.Show(cliente.getStatus(ticket).statusCode);
            //MessageBox.Show(cliente.getStatus(ticket).content.ToString());
            File.WriteAllBytes("E:\\R-"+filename, cliente.getStatus(ticket).content);
            var a = Convert.ToBase64String(ContentFile);
            
        }

        public static void AgregaPrefijo(XmlNode n)
        {
            string[] nodos = {"SignedInfo", "CanonicalizationMethod", "Reference", "SignatureMethod", "Transforms", "Transform", "DigestMethod", "DigestValue",
            "SignatureValue", "KeyInfo", "X509Data", "X509SubjectName", "X509Certificate"};
            //int reference = 0;
            try
            {
                foreach (XmlElement item in n.Cast<XmlNode>().Where(e => e.NodeType == XmlNodeType.Element))
                {
                    string nombre = item.Name;
                    if (nodos.Contains(nombre))
                    {
                        item.Prefix = "ds";
                        if (item.HasChildNodes)
                        {
                            AgregaPrefijo(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               ex.ToString();
            }
        }        
    }
}
