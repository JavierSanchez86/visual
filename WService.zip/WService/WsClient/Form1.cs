﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WsClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            Converter.ConverterSoapClient client = new Converter.ConverterSoapClient("ConverterSoap");//CONTRACT - name
            decimal dblValorIngreso = Decimal.Parse(txtValorEntrada.Text);
            decimal ValorSalida = client.GetConversionAmount("USD", "EUR", DateTime.Now, dblValorIngreso);//El metodo del WS
            //Console.WriteLine(ValorSalida);
            MessageBox.Show(ValorSalida.ToString());
        }
    }
}
